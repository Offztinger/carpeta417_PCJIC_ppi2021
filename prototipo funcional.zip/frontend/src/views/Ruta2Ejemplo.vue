<template>
  <div class="Ruta2Ejemplo">
    <h1>Pagina 2 de ejemplo</h1>
  </div>
</template>
