package com.saferide.saferide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaferideApplicationTests {

    @Test
    void contextLoads() {
    }

}
