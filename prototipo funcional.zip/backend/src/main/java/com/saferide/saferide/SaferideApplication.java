package com.saferide.saferide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaferideApplication {

    public static void main(String[] args) {
        SpringApplication.run(SaferideApplication.class, args);
    }

}
