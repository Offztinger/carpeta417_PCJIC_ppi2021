package com.saferide.saferide.repositories;

import com.saferide.saferide.models.HurtoModel;
import org.springframework.data.repository.CrudRepository;

public interface HurtoRepository extends CrudRepository<HurtoModel, String> {

}
